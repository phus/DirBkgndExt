// BkgndCtxMenuExt.cpp : Implementation of CBkgndCtxMenuExt
#include "stdafx.h"
#include "DirBkgndExt.h"
#include "BkgndCtxMenuExt.h"

/////////////////////////////////////////////////////////////////////////////
// CBkgndCtxMenuExt

STDMETHODIMP CBkgndCtxMenuExt::Initialize (
                                 LPCITEMIDLIST pidlFolder,
                                 LPDATAOBJECT  pDO,
                                 HKEY          hkeyProgID )
{
    // pidlFolder is the PIDL of the directory that was clicked in.  pDO is
    // NULL, since there is no selection to operate on.
    // We get the conventional path of the directory from its PIDL with the
    // SHGetPathFromIDList() API.
	
	//return SHGetPathFromIDList ( pidlFolder, m_szDirClickedIn ) ? S_OK : E_INVALIDARG;
	return CSIDL_DESKTOP == pidlFolder->mkid.cb ? S_OK : E_INVALIDARG;
}

STDMETHODIMP CBkgndCtxMenuExt::QueryContextMenu (
                                 HMENU hmenu, UINT uIndex, UINT uidCmdFirst,
                                 UINT uidCmdLast, UINT uFlags )
{
	UINT uCmdID = uidCmdFirst;
	static TCHAR* s_lpszMenuTitle=NULL;

    // First insert item 0 - the English version.
	if (NULL == s_lpszMenuTitle)
	{
		s_lpszMenuTitle = new TCHAR[MAX_PATH];
		LPWSTR clsid;
		StringFromCLSID(CLSID_BkgndCtxMenuExt, &clsid);
		wsprintf(s_lpszMenuTitle, L"CLSID\\%s", clsid);
		SysFreeString(clsid);
		
		HKEY hKey;
		int ret = RegOpenKeyExW(HKEY_CLASSES_ROOT, s_lpszMenuTitle, 0, KEY_ALL_ACCESS, &hKey);
		DWORD dwType, dwSize;
		ret = RegQueryValueExW(hKey, L"MenuTitle", 0, &dwType, (LPBYTE)s_lpszMenuTitle, &dwSize);
		if (ret)
		{
			wcscpy(s_lpszMenuTitle, L"BkgndCtxMenuExt");
		}
		RegCloseKey(hKey);
	}

    InsertMenu ( hmenu, uIndex, MF_BYPOSITION, uCmdID, s_lpszMenuTitle);

    return MAKE_HRESULT ( SEVERITY_SUCCESS, FACILITY_NULL, 2 );
}

STDMETHODIMP CBkgndCtxMenuExt::GetCommandString (
                                 UINT uCmd, UINT uFlags, UINT* puReserved,
                                 LPSTR pszName, UINT cchMax )
{
    return S_OK;
}

STDMETHODIMP CBkgndCtxMenuExt::InvokeCommand ( LPCMINVOKECOMMANDINFO pInfo )
{

	WORD wCmd = LOWORD( pInfo->lpVerb );

    // If lpVerb really points to a string, ignore this function call and bail out.
    if ( 0 != HIWORD( pInfo->lpVerb ))
        return E_INVALIDARG;

    // The command ID must be 0 or 1 since we have two menu items.
    if ( wCmd != 0 )
        return E_INVALIDARG;

    if ( 0 == wCmd )
    {
		TCHAR szMenuCommand[MAX_PATH+32];
		TCHAR szKeyName[MAX_PATH+32];
		LPWSTR clsid;
		StringFromCLSID(CLSID_BkgndCtxMenuExt, &clsid);
		wsprintf(szKeyName, L"CLSID\\%s", clsid);
		SysFreeString(clsid);
		
		HKEY hKey;
		LONG ret = RegOpenKeyExW(HKEY_CLASSES_ROOT, szKeyName, 0, KEY_ALL_ACCESS, &hKey);
		DWORD dwType, dwSize=sizeof(szMenuCommand);
		ret = RegQueryValueExW(hKey, L"MenuCommand", 0, &dwType, (LPBYTE)szMenuCommand, &dwSize);
		RegCloseKey(hKey);
		if (!ret)
		{
			ShellExecute(NULL, L"open", szMenuCommand, L"", L"", SW_SHOW);
		}
    }

    return S_OK;
}
