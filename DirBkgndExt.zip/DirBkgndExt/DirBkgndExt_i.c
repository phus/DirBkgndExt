/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun May 10 14:34:58 2009
 */
/* Compiler settings for C:\DirBkgndExt\DirBkgndExt.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IBkgndCtxMenuExt = {0x6F6B303F,0x2EAD,0x4973,{0x89,0xEE,0x5F,0xCE,0xC7,0x25,0x79,0x62}};


const IID LIBID_DIRBKGNDEXTLib = {0xB377AEE3,0x6F79,0x4C28,{0xA8,0xEA,0x89,0xE6,0xA6,0xBE,0x8F,0x45}};


const CLSID CLSID_BkgndCtxMenuExt = {0x9E5E1445,0x6CEA,0x4761,{0x8E,0x45,0xAA,0x19,0xF6,0x54,0x57,0x1E}};


#ifdef __cplusplus
}
#endif

